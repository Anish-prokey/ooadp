
public class Client {

	public static void main(String[] args) {

		float billAmount = (float) 20250.50;
		Facade fc = new Facade(true, billAmount);

		fc.calculateAmountToPay();
		fc.displayItemsPurchased();

	}

}
