

public interface DiscountSlab {
	String Name = "Cricket Bat";
	int price = 1000;
	int quantity = 2;
	
	void CalcDiscount(float r);
}
