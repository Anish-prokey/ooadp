
public abstract class Outdoor extends SportStock {
	@Override
	public abstract void stock();

}
