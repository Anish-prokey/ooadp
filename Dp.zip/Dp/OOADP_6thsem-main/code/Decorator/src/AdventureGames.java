
public class AdventureGames extends Outdoor {

	@Override
	public void stock() {
		System.out.println("STOCK of outdoor AdventureGames:100");
	}
}
