
public abstract class Indoor extends SportStock {

	@Override
	public abstract void stock();

}
