
public class GamesOnTable extends Indoor {
	 
	@Override
	public void stock(){
		System.out.println("STOCK of Indoor _ GAME ON TABLE:200");
	}
}
