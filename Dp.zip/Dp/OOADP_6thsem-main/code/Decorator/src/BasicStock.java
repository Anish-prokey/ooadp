
public class BasicStock extends getcurrentStock {
	@Override
	public void stock() {
		System.out.println("Basic Stocks: 100");
	}
}
