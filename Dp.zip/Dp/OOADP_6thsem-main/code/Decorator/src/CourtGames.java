
public class CourtGames extends Indoor {

	@Override
	public void stock() {
		System.out.println("STOCK of Indoor CourtGames :100");
	}

}
