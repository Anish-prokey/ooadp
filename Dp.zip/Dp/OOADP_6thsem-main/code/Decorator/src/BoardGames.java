
public class BoardGames extends Indoor {

	@Override
	public void stock() {
		System.out.println("STOCK of INDOOR BOARD GAME:100");
	}

}
