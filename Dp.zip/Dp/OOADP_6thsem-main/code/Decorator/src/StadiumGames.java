
public class StadiumGames extends Outdoor {

	@Override
	public void stock() {
		System.out.println("STOCK of outdoor Stadiumgames :100");
	}
}
