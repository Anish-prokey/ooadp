
public class Athletics extends Outdoor {

	@Override
	public void stock() {
		System.out.println("STOCK of outdoor Athletics :100");
	}

}
