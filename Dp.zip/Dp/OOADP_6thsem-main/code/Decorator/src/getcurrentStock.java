
public abstract class getcurrentStock {
	public getcurrentStock() {
		
	}
	public abstract void stock();
}
