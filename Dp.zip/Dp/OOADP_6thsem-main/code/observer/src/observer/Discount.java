package observer;

public abstract class Discount {
	protected Store store;
	public abstract void update();
}
