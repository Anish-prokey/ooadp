
public class Abled extends Person {
	public Abled(String name) {
		this.name = name;
	}
}
