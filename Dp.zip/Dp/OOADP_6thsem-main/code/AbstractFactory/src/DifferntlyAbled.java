
public class DifferntlyAbled extends Person {
	public DifferntlyAbled(String name) {
		this.name = name;
	}
}
