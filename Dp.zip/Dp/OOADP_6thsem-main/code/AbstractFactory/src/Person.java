
public class Person {
	String name;
}
