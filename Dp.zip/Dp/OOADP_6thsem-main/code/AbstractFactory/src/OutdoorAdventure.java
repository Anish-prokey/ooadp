
public class OutdoorAdventure extends Sport{
	public OutdoorAdventure(String name) {
		this.name = name;
	}
}
