
public class Sport {
	public String name;
}
