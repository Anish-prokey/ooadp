
public class IndoorRegular extends Sport{
	public IndoorRegular(String name) {
		this.name = name;
	}
}
