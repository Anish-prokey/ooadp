
public abstract class abstractFactory {
	public abstract void getSport();
	public abstract void getPerson();
	public abstract void display();
}
