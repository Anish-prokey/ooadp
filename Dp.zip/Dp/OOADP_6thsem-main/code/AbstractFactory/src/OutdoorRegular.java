
public class OutdoorRegular extends Sport{
	public OutdoorRegular(String name) {
		this.name = name;
	}
}
