
public class TaxAdapterDemo {
	public static void main(String[] args) {
		SwedenTax st = new SwedenTax();
		Item i1 = new Item("Btwin Roackroder 340", 13999.0, st);
		i1.setQunatity(3);  // Here we are testing for Sweden tax
		i1.printPrice();
		i1.setTax(new MyMauritiusTax());  // Here we are testing for Mauritius tax tax
		i1.printPrice();
	}

}
