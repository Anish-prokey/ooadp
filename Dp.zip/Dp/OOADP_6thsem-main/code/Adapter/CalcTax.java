
public interface CalcTax {
	double taxAmount(String item, int qty, double price);

}
