
public class NewMauritiusTax {
	double calcTax(int qntty, double price) {
		return price*qntty*(0.25f);
	}
	

}
