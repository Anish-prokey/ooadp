public interface iDiscountCalculator {
	
	public void calculateBillAmount(double mrptotal); 
	
}
